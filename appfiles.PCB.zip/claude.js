const { app } = require('@azure/functions');

/**
 * POST /api/claude
 * Body: { prompt: string, useMcp?: boolean }
 *
 * Holds the Anthropic API key server-side (browser never sees it).
 * When useMcp is true AND a Microsoft 365 MCP server is configured, it
 * re-attaches the M365 tools to the request so Outlook features work
 * exactly as they did inside Claude.ai. Returns the raw Anthropic
 * response body, so the front-end's allText()/parseJson() keep working.
 *
 * App settings (set in Azure portal → Static Web App → Configuration):
 *   ANTHROPIC_API_KEY   (required)
 *   CLAUDE_MODEL        (optional, default below)
 *   M365_MCP_URL        (optional — enables Outlook features)
 *   M365_MCP_TOKEN      (optional — bearer token for that MCP server)
 */
app.http('claude', {
  methods: ['POST'],
  authLevel: 'anonymous', // route is already gated to logged-in users in staticwebapp.config.json
  handler: async (request, context) => {
    const key = process.env.ANTHROPIC_API_KEY;
    if (!key) {
      return { status: 500, jsonBody: { error: 'Server is missing ANTHROPIC_API_KEY.' } };
    }

    let payload;
    try { payload = await request.json(); }
    catch { return { status: 400, jsonBody: { error: 'Invalid JSON body.' } }; }

    const prompt = payload && payload.prompt;
    const useMcp = !!(payload && payload.useMcp);
    if (!prompt) return { status: 400, jsonBody: { error: 'Missing prompt.' } };

    const model = process.env.CLAUDE_MODEL || 'claude-sonnet-4-20250514';
    const body = {
      model,
      max_tokens: 1024,
      messages: [{ role: 'user', content: prompt }]
    };

    const headers = {
      'content-type': 'application/json',
      'x-api-key': key,
      'anthropic-version': '2023-06-01'
    };

    const mcpUrl = process.env.M365_MCP_URL;
    const mcpToken = process.env.M365_MCP_TOKEN;

    if (useMcp) {
      if (!mcpUrl) {
        // Outlook tool source not wired yet — fail cleanly and clearly.
        return {
          status: 503,
          jsonBody: { error: "Outlook isn't connected yet (no Microsoft 365 server configured)." }
        };
      }
      body.mcp_servers = [{
        type: 'url',
        url: mcpUrl,
        name: 'microsoft365',
        ...(mcpToken ? { authorization_token: mcpToken } : {})
      }];
      headers['anthropic-beta'] = 'mcp-client-2025-11-20';
    }

    try {
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers,
        body: JSON.stringify(body)
      });
      const data = await res.json();
      if (!res.ok) {
        const msg = (data && data.error && data.error.message) || ('Anthropic error ' + res.status);
        return { status: res.status, jsonBody: { error: msg } };
      }
      return { status: 200, jsonBody: data };
    } catch (e) {
      context.error(e);
      return { status: 502, jsonBody: { error: 'Upstream request failed.' } };
    }
  }
});
