# CCI QA Operations — deploy bundle (with secure backend)

This is the QA app plus a small Azure Functions backend that holds your
Anthropic API key server-side and brokers the Outlook features.

## What's in here

```
qa-ops/
  index.html                      ← the app (now calls /api/claude, not Anthropic directly)
  staticwebapp.config.json        ← tenant-locked login + Node runtime + secured /api
  api/
    host.json
    package.json                  ← only dependency is @azure/functions
    src/functions/claude.js       ← the secure proxy
```

Put this whole folder in a GitHub repo and point an Azure Static Web App at it.
Set **App location = `/`** and **API location = `api`** in the deploy step.

## One-time setup

### 1. Anthropic API key (required for any AI feature)
- Create an account at console.anthropic.com (this is a billable account,
  separate from your Claude subscription) and generate an API key.
- In Azure → your Static Web App → **Configuration** → add application setting:
  - `ANTHROPIC_API_KEY` = your key
- That alone makes "Optimize routes" and any pure-reasoning feature work.

### 2. Reuse the same login (no new Entra app)
- In `staticwebapp.config.json`, replace `YOUR_TENANT_ID` with your tenant ID.
- Add the two settings you already used for the portal:
  - `AAD_CLIENT_ID`, `AAD_CLIENT_SECRET`
- Add this app's callback URL to your existing Entra app registration:
  `https://<this-app-url>/.auth/login/aad/callback`

### 3. Outlook features (optional, do when ready)
The Outlook buttons (Sync, Push, Day summary, Fleet refresh) need a
**Microsoft 365 MCP server** the backend can reach. The Claude.ai built-in
connector can't be reused from your own server, so you supply one of your own.
Two paths:
- **Self-host an open-source Microsoft 365 / Graph MCP server**, authenticated
  to your tenant with an Entra app (Graph permissions: Mail.Read, Mail.Send,
  Calendars.ReadWrite — granted with admin consent).
- **Use a hosted M365 MCP provider** that issues you a URL + token.

Then add two settings to the Static Web App:
- `M365_MCP_URL`   = that server's URL
- `M365_MCP_TOKEN` = its bearer token (if it requires one)

No app or function code changes needed — the proxy attaches the tools
automatically and every Outlook feature lights up. Until these are set, those
buttons fail cleanly with "Outlook isn't connected yet."

## Notes
- `/api/*` is restricted to logged-in CCI users, so nobody outside your tenant
  can burn your Anthropic key.
- If the build complains about Node 18, change `apiRuntime` to `node:20`.
- Client secrets expire — set a reminder to rotate `AAD_CLIENT_SECRET`.
